#include <iostream>

int main() {
    std::cout << "Hello, C++ is working!" << std::endl;
    return 0;
} 